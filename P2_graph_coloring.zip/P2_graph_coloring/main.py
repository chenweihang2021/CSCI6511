from copy import deepcopy
import time


class Problem:
    def __init__(self, num_colors, vertices, edges):
        """
        num_colors: number of colors, an integer
        vertices: list of vertices(integer), e.g. [1, 2, 3, 4]
        edges: list of edges(tuples), e.g. [(1, 8), (8, 19)]
        """
        self.variables = vertices
        self.domains = {
            var: list(range(num_colors))
            for var in self.variables
        }  # every vertex represented by a var

        self.edges = edges

    def solve(self):
        if self.ac3():
            return self.backtrack(dict())

    def revise(self, x, y):
        """
        Make variable `x` arc consistent with variable `y`.
        To do so, remove values from `self.domains[x]` for which there is no
        possible corresponding value for `y` in `self.domains[y]`.

        Return True if a revision was made to the domain of `x`; return
        False if no revision was made.
        """
        revised = False
        connected = (x, y) in self.edges or (y, x) in self.edges
        if connected:
            for vx in self.domains[x]:
                exist_correspond_y = False
                for vy in self.domains[y]:
                    if vx != vy:
                        exist_correspond_y = True
                if not exist_correspond_y:
                    self.domains[x].remove(x)
                    revised = True
        
        return revised

    def ac3(self, arcs=None):
        """
        Update `self.domains` such that each variable is arc consistent.
        If `arcs` is None, begin with initial list of all arcs in the problem.
        Otherwise, use `arcs` as the initial list of arcs to make consistent.

        Return True if arc consistency is enforced and no domains are empty;
        return False if one or more domains end up empty.
        """
        if not arcs:
            arcs = [(x, y) for x in self.variables for y in self.variables if x != y]
        while arcs:
            for x, y in arcs:
                if self.revise(x, y):
                    if self.neighbors(x):
                        for neighbor in self.neighbors(x):
                            arcs.append((neighbor, x))
                
                arcs.remove((x, y))
        
        for domain in self.domains.values():
            if not domain:
                return False
        return True

    def assignment_complete(self, assignment):
        """
        Return True if `assignment` is complete (i.e., assigns a value to each
        crossword variable); return False otherwise.
        """
        if len(assignment) < len(self.variables):
            return False

        for var in assignment.keys():
            if assignment[var] is None:
                return False

        return True

    def select_unassigned_variable(self, assignment):
        """
        MRV
        Return an unassigned variable not already part of `assignment`.
        Choose the variable with the minimum number of remaining values
        in its domain. If there is a tie, choose the variable with the highest
        degree. If there is a tie, any of the tied variables are acceptable
        return values.
        """
        unassigned = []
        for var in self.variables:
            if var not in assignment.keys():
                unassigned.append(var)
                
        for var in list(assignment.keys()):
            if assignment[var] is None:
                unassigned.append(var)
        from random import choice
        return choice(unassigned)
        # return min(unassigned, key=lambda x: len(self.domains[x]))

    def order_domain_values(self, var, assignment):
        """
        Return a list of values in the domain of `var`, in order by
        the number of values they rule out for neighboring variables.
        The first value in the list, for example, should be the one
        that rules out the fewest values among the neighbors of `var`.
        """
        # unassigned = set(self.variables) - set(assignment.keys())
        unassigned = []
        for var in self.variables:
            if var not in assignment.keys():
                unassigned.append(var)
                
        for var in list(assignment.keys()):
            if assignment[var] is None:
                unassigned.append(var)

        values = list(self.domains[var])

        def rule_out(value):
            count = 0
            for variable in unassigned:
                if value in self.domains[variable]:
                    count += 1
            return count
        values.sort(key=lambda x: rule_out(x))

        return values
        
    def consistent(self, assignment):
        """
        Return True if `assignment` is consistent, return False otherwise.
        """
        assigned = []
        for var in list(assignment.keys()):
            if assignment[var] is not None:
                assigned.append(var)
                
        for edge in self.edges:
            i, j = edge
            if i in assigned and j in assigned:
                if assignment[i] == assignment[j]:
                    return False

        return True

    def backtrack(self, assignment):
        """
        Using Backtracking Search, take as input a partial assignment for the
        crossword and return a complete assignment if possible to do so.

        `assignment` is a mapping from variables (keys) to words (values).

        If no assignment is possible, return None.
        """
        global start
        if time.time()-start > 20:
            # print(f"Time out, {time.time()-start} seconds")
            return False
            
        if self.assignment_complete(assignment):
            return assignment
        
        var = self.select_unassigned_variable(assignment)
        a2 = deepcopy(assignment)
        for value in self.order_domain_values(var, assignment):
            a2[var] = value
            if self.consistent(a2):
                result = self.backtrack(deepcopy(a2))
                if result:
                    return result
                else:
                    a2[var] = None
            # else:
                # a2[var] = None

        return False

    def neighbors(self, x):
        neighbors = []
        for edge in self.edges:
            i, j = edge
            if x == i:
                neighbors.append(j)
            if x == j:
                neighbors.append(i)
        
        return neighbors


def main():
    global start
    start = time.time()
    filename = input("Enter filename: ")
    f = open(filename)
    lines = f.readlines()
    useful_lines = []
    for line in lines:
        if line[0] != '#':
            useful_lines.append(line)

    num_colors = int(useful_lines[0].strip()[-1])
    edges = []
    vertices = []
    for line in useful_lines[1:]:
        l = line.strip().split(',')
        i, j = int(l[0]), int(l[1])
        edges.append((i, j))

        if i not in vertices:
            vertices.append(i)
        if j not in vertices:
            vertices.append(j)

    problem = Problem(num_colors=num_colors, vertices=vertices, edges=edges)
    solution = problem.solve()
    if solution:
        print(solution)
    else:
        print("No solution")
    # solution is a dictionary, mapping variables to colors, while colors are represented by integers


if __name__ == "__main__":
    main()
